We hold that Data, Truth, and Trust are necessary and sufficient conditions for Identity.

In other words, Identity is an emergent property.


![Identity_Schematic](Identity_Schematic.png)